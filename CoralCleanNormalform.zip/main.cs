using System;

public class Program
{
    public static void Main(string[] args)
    {
        // Отримання тексту
        Console.WriteLine("Введіть текст:");
        string text = Console.ReadLine();

        // Розбиття тексту на слова
        string[] words = text.Split(' ');

        // Обчислення загальної довжини слів
        int totalWordLength = 0;
        foreach (string word in words)
        {
            totalWordLength += word.Length;
        }

        // Середня довжина слова
        double averageWordLength = (double)totalWordLength / words.Length;

        // Виведення результату
        Console.WriteLine($"Середня довжина слова: {averageWordLength}");
    }
}
